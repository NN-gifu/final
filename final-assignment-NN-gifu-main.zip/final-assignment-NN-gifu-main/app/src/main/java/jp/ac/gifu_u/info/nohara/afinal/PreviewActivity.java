package jp.ac.gifu_u.info.nohara.afinal;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import jp.ac.gifu_u.info.nohara.afinal.databinding.ActivityPreviewBinding;

public class PreviewActivity extends AppCompatActivity {

    private ActivityPreviewBinding binding;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPreviewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String imageUriString = getIntent().getStringExtra("image_uri");
        if (imageUriString != null) {
            imageUri = Uri.parse(imageUriString);
            binding.imageView.setImageURI(imageUri);
        } else {
            Toast.makeText(this, "画像の読み込みに失敗しました", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 「再撮影」ボタンの処理
        binding.retakeButton.setOnClickListener(v -> {
            // 不要になった画像ファイルを削除する
            if (imageUri != null) {
                getContentResolver().delete(imageUri, null, null);
            }
            finish();
        });

        // 「Xへ投稿」ボタンの処理
        binding.xButton.setOnClickListener(v -> {
        });

        // 「イラストへ変換」ボタンの処理
        binding.illustrationButton.setOnClickListener(v -> {
        });
    }
}